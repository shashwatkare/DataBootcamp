sub HW2():
    DIM Unique_Ticker AS INTEGER
    DIM Total_Volume AS INTEGER
    DIM Percent_Change AS INTEGER 
    DIM Yearly_Change AS INTEGER 
    DIM SUMMARY_Labels AS INTEGER 
    DIM SUMMARY_Ticker AS INTEGER 
    DIM SUMMARY_Value AS INTEGER 
    DIM ws AS WorkSheet 
    DIM wsc AS INTEGER
    DIM rALL As Range

    ''''' Show the column number for each item '''''
    Unique_Ticker = 9
    Yearly_Change = 10
    Percent_Change = 11 
    Total_Volume = 12
    SUMMARY_Labels = 15
    SUMMARY_Ticker = 16
    SUMMARY_Value = 17

    ''''' Find how many worksheets in this workbook'''''
    Sheets_Count = Sheets.Count
    'MsgBox Sheets.Count & " sheets available"
    
    ''''' Loop through every workseet '''''
    FOR wsc = 1 TO Sheets_Count:
        ''''' activate the worksheet which is working '''''
        set ws = Sheets(wsc)
        ws.Activate

        WITH ws

            ''''' The following two lines: Copy Column(1) and remove duplicate at Column(Unique_ticker) '''''        
            .Columns(1).Copy Destination:=.Columns(Unique_Ticker)
            .Columns(Unique_Ticker).RemoveDuplicates Columns:=1, Header:=xlYes

            ''''' The following two lines: alllr = counting rows for the Column(1); lr = counting rows for unique tickers '''''
            alllr = .Cells(Rows.Count, 1).End(xlUp).Row
            lr = .Cells(Rows.Count, Unique_Ticker).End(xlUp).Row

            ''''' The loop go through every unique ticker '''''
            FOR i = 2 TO lr:

                ''''' The following lines are to sum the volumn for specfic unqiue ticker '''''
                TICKER_NAME = .Cells(i, Unique_Ticker)
                .Cells(i, Total_Volume) = Application.WorksheetFunction.SumIf(.Range("A:A"), TICKER_NAME, .Range("G:G"))

                ''''' The following LOOP is to find the range in column(1) that has the unique ticker = rALL '''''
                IF i = 2 THEN 
                    RANGE_START = 2
                END IF 

                FOR j = RANGE_START TO alllr:
                    IF .Cells(j, 1) <> TICKER_NAME THEN
                        set rALL = .RANGE("B" & CStr(RANGE_START) & ":B" & CStr(J-1))
                        RANGE_START = j
                        EXIT FOR
                    END IF 
                NEXT j

                ''''' The following process is to find the first date price and last date price, and then calculates yearly change '''''
                START_DATE = Application.WorksheetFunction.Min(rALL)
                END_DATE = Application.WorksheetFunction.Max(rALL)
                START_DATE_MATCH = Application.WorksheetFunction.Match(START_DATE, rALL, 0)
                END_DATE_MATCH = Application.WorksheetFunction.Match(END_DATE, rALL, 0)
                START_DATE_CLOSEPRICE = Application.WorksheetFunction.Index(rALL.Offset(0, 4), START_DATE_MATCH)
                END_DATE_CLOSEPRICE = Application.WorksheetFunction.Index(rALL.Offset(0, 4), END_DATE_MATCH)
                .Cells(i, Yearly_Change) = END_DATE_CLOSEPRICE - START_DATE_CLOSEPRICE

                ''''' Do conditional formatting for Yearly_Change: negative - red (index=3); positive (including 0) - green (index=4) '''''
                IF .Cells(i, Yearly_Change) >=0 THEN
                    .Cells(i, Yearly_Change).Interior.ColorIndex = 4
                ELSE 
                    .Cells(i, Yearly_Change).Interior.ColorIndex = 3
                END IF

                ''''' Use first date price and yearly change to calculate percent change '''''
                .Cells(i, Percent_Change).NumberFormat = "0.00%" 
                IF START_DATE_CLOSEPRICE = 0 THEN 
                    .Cells(i, Percent_Change) = 0
                ELSE
                    .Cells(i, Percent_Change) = (END_DATE_CLOSEPRICE - START_DATE_CLOSEPRICE)/START_DATE_CLOSEPRICE
                END IF 
               
            NEXT i
            ''''' Put description at certain cells '''''
            .Cells(2,SUMMARY_Labels) = "Greatest % Increase"
            .Cells(3,SUMMARY_Labels) = "Greatest % Decrease"
            .Cells(4,SUMMARY_Labels) = "Greatest Total Volume"

            ''''' Find greatest percent increase value and ticker '''''
            GREATEST_PERCENT_INCREASE_VALUE = Application.WorksheetFunction.Max(.Columns(Percent_Change))
            GREATEST_PERCENT_INCREASE_MATCH = Application.WorksheetFunction.Match(GREATEST_PERCENT_INCREASE_VALUE, .Columns(Percent_Change), 0)
            GREATEST_PERCENT_INCREASE_TICK = Application.WorksheetFunction.Index(.Columns(Percent_Change).offset(0,-2), GREATEST_PERCENT_INCREASE_MATCH)
            .Cells(2,SUMMARY_Ticker) = GREATEST_PERCENT_INCREASE_TICK
            .Cells(2,SUMMARY_Value).NumberFormat = "0.00%" 
            .Cells(2,SUMMARY_Value) = GREATEST_PERCENT_INCREASE_VALUE

            ''''' Find greatest percent decrease value and ticker '''''
            GREATEST_PERCENT_DECREASE_VALUE = Application.WorksheetFunction.Min(.Columns(Percent_Change))
            GREATEST_PERCENT_DECREASE_MATCH = Application.WorksheetFunction.Match(GREATEST_PERCENT_DECREASE_VALUE, .Columns(Percent_Change), 0)
            GREATEST_PERCENT_DECREASE_TICK = Application.WorksheetFunction.Index(.Columns(Percent_Change).offset(0,-2), GREATEST_PERCENT_DECREASE_MATCH)
            .Cells(3,SUMMARY_Ticker) = GREATEST_PERCENT_DECREASE_TICK
            .Cells(3,SUMMARY_Value).NumberFormat = "0.00%" 
            .Cells(3,SUMMARY_Value) = GREATEST_PERCENT_DECREASE_VALUE
        
            ''''' Find greatest total volume value and ticker '''''
            GREATEST_TOTAL_VOLUME_VALUE = Application.WorksheetFunction.Max(.Columns(Total_Volume))
            GREATEST_TOTAL_VOLUME_MATCH = Application.WorksheetFunction.Match(GREATEST_TOTAL_VOLUME_VALUE, .Columns(Total_Volume), 0)
            GREATEST_TOTAL_VOLUME_TICK = Application.WorksheetFunction.Index(.Columns(Total_Volume).offset(0,-3), GREATEST_TOTAL_VOLUME_MATCH)
            .Cells(4,SUMMARY_Ticker) = GREATEST_TOTAL_VOLUME_TICK
            .Cells(4,SUMMARY_Value) = GREATEST_TOTAL_VOLUME_VALUE
        
            ''''' Just insert the header '''''
            .Cells(1,Unique_Ticker) = "Ticker"
            .Cells(1,Yearly_Change) = "Yearly Change"
            .Cells(1,Percent_Change) = "Percent Change"
            .Cells(1,Total_Volume) = "Total Stock Volume"
            .Cells(1,SUMMARY_Ticker) = "Ticker"
            .Cells(1,SUMMARY_Value) = "Value"

            ''''' Adjust column width '''''
            .Columns(Unique_Ticker).EntireColumn.AutoFit
            .Columns(Yearly_Change).EntireColumn.AutoFit
            .Columns(Percent_Change).EntireColumn.AutoFit
            .Columns(Total_Volume).EntireColumn.AutoFit
            .Columns(SUMMARY_Labels).EntireColumn.AutoFit
            .Columns(SUMMARY_Ticker).EntireColumn.AutoFit
            .Columns(SUMMARY_Value).EntireColumn.AutoFit


        end WITH
    NEXT wsc

end sub 
